import unittest
import telebot
import requests
from telebot import types

bot = telebot.TeleBot('5957234710:AAFt1IZ7KG4M37kxsbZFHOKTubOT2rk6YVo')
appid = '78db3afcc8f32dd3faf7e3ef49dd46a1'
s_city = "Moscow (RU)"
city_id = 0


@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("Погода")
    btn2 = types.KeyboardButton("Температура")
    markup.add(btn1, btn2)
    if type(message) != str:
        bot.send_message(message.chat.id, text="Я родился!", reply_markup=markup)
    else:
        raise Exception("Message is str, not telebot object")

    global message1

    message1 = message

    if message == None:
        return None

    return message1


@bot.message_handler(content_types=['text'])
def func(message):
    try:
        res = requests.get(
            f"http://api.openweathermap.org/data/2.5/forecast?id=524901&appid={appid}&lang=ru&units=metric")
        data = res.json()
        if (not data) or (str(data['cod']) == '404'):
            raise Exception('Page not Found 404')
    except Exception as e:
        bot.send_message(message.chat.id, text=f"Сервер упал :(\nОшибка: {e}")
        return
    if message == None:
        return
    if message.text == "Погода":
        weather = data['list'][0]['weather'][0]['description'].title()
        bot.send_message(message.chat.id, text=weather)
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        back = types.KeyboardButton("Назад")
        markup.add(back)

    elif message.text == "Температура":
        temp = 'Температура ' + str(data['list'][0]['main']['temp']) + '°C'
        feels_temp = 'Ощущается как ' + str(data['list'][0]['main']['feels_like']) + '°C'
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        bot.send_message(message.chat.id, text=temp + "\n" + feels_temp, reply_markup=markup)
        back = types.KeyboardButton("Назад")
        markup.add(back)

    elif message.text == "Назад":
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        button1 = types.KeyboardButton("Погода")
        button2 = types.KeyboardButton("Температура")
        markup.add(button1, button2)
        bot.send_message(message.chat.id, text="Вы вернулись в главное меню, чем могу помочь?", reply_markup=markup)
    else:
        bot.send_message(message.chat.id, text="Не знаю такого..")


class test_class(unittest.TestCase):
    def test_false_parameters(self):
        with self.assertRaises(Exception) as context:
            start("text")
        self.assertEqual(
            "Message is str, not telebot object",
            str(context.exception)
        )

    def test_zero_parameters(self):
        with self.assertRaises(TypeError) as context:
            start()
        self.assertEqual(
            "start() missing 1 required positional argument: 'message'",
            str(context.exception)
        )

    def test_func(self):
        message1 = None
        self.assertEqual(func(message1), None)

    def test_func_zero_parameters(self):
        with self.assertRaises(TypeError) as context:
            func()
        self.assertEqual(
            "func() missing 1 required positional argument: 'message'",
            str(context.exception)
        )


bot.polling(none_stop=True)
unittest.main()
